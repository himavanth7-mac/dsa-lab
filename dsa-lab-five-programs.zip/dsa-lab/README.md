# DSA Lab C Programs

C programs transcribed from the supplied `Lab 1_Content.pdf`:

| Filename | Topic in PDF |
| --- | --- |
| `1a.c` | Array operations |
| `1b.c` | Matrix multiplication |
| `2a.c` | Merge sort |
| `2b.c` | Quick sort |
| `3a.c` | Singly linked list (PDF section **3. Linked List**) |

**Numbering note:** The supplied PDF calls the linked-list program `3. Linked List` and separately lists `3. a. I.` as a stack implemented using a linked list. This package names the linked-list program `3a.c` to match the five programs discussed. Confirm which one your instructor means by `3a`.

The programs follow the handout, with one repair to an invalid PDF-wrapped `printf` string in `1b.c`. No input-validation improvements have been added.

## Ubuntu quick start

```bash
git clone https://github.com/YOUR_USERNAME/dsa-lab.git
cd dsa-lab
ls
cat 1a.c
# To open the original code in a graphical editor:
gedit 1a.c
# Compile and run:
gcc 1a.c -o 1a
./1a
```

Run `git pull` inside the cloned folder to get later changes.
